# Snek // EXTREME

## By [tyuXX](https://github.com/tyuXX)

## Description
Snek, but extreme.

## How to play
bro who cares

## Controls
- Arrow keys or WASD to move the snake.
- Spacebar to pause the game.